# Detecção de embarcações > 2025-08-18 4:54pm
https://universe.roboflow.com/deteco-de-embarcaes/deteccao-de-embarcacoes-mmbpl

Provided by a Roboflow user
License: CC BY 4.0

Anotação de amostras para detecção de embarcações.
